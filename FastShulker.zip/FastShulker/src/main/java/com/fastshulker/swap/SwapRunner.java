package com.fastshulker.swap;

import com.fastshulker.FastShulkerClient;
import com.fastshulker.config.FastShulkerConfig;
import com.fastshulker.config.Preset;
import com.fastshulker.util.ShulkerUtil;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Maszyna stanow wykonujaca zamiane:
 * postaw shulkera -> otworz -> zamien sloty -> (pancerz: 2 dodatkowe etapy) -> zamknij -> zniszcz -> podnies.
 * Jeden etap na tick (z opoznieniem z configu); etapy czekajace na serwer zwracaja false.
 */
public final class SwapRunner {
    private SwapRunner() {}

    private interface Step { boolean run(MinecraftClient mc, Ctx c); }
    private record Entry(Step step, int timeout) {}

    private static final class Ctx {
        Preset preset;
        int[] layout;
        int shulkerHotbar;
        int origSelected;
        BlockPos pos;
        /** indeksy ekwipunku (9-35) uzywane jako bufor przy zamianie pancerza */
        int[] buf = new int[4];
        boolean placeSent, openSent, breakStarted, cleaning;
        int settle, wait;
    }

    private static final Deque<Entry> queue = new ArrayDeque<>();
    private static Ctx ctx;
    private static boolean active;
    private static int cooldown, stepAge;

    public static boolean isRunning() { return active; }

    // ------------------------------------------------------------------ start

    public static void start(MinecraftClient mc, Preset p) {
        if (active || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.player.isSpectator()) return;
        if (p.isEmpty()) { msg(mc, "Preset jest pusty - ustaw uklad w menu."); return; }
        if (ShulkerUtil.find(mc.player.getInventory(), p) < 0) {
            msg(mc, "Nie znaleziono shulkera z presetu \"" + p.name + "\" w ekwipunku.");
            return;
        }
        BlockPos pos = findPlacePos(mc);
        if (pos == null) { msg(mc, "Brak wolnego miejsca obok Ciebie na shulkera."); return; }

        Ctx c = new Ctx();
        c.preset = p;
        c.layout = p.layout.clone();
        c.pos = pos;
        c.origSelected = mc.player.getInventory().selectedSlot;

        boolean armor = false;
        for (int k = 10; k <= 13; k++) if (c.layout[k] >= 0) armor = true;

        queue.clear();
        add(SwapRunner::prep, 20);
        add(SwapRunner::place, 40);
        add(SwapRunner::open, 40);
        add(SwapRunner::swapInside, 20);
        if (armor) {
            add(SwapRunner::closeScreen, 20);
            add(SwapRunner::equipArmor, 20);
            add(SwapRunner::open, 40);
            add(SwapRunner::restoreArmor, 20);
        }
        add(SwapRunner::closeScreen, 20);
        add(SwapRunner::breakBlock, 600);
        add(SwapRunner::waitPickup, 40);

        ctx = c;
        active = true;
        cooldown = 0;
        stepAge = 0;
    }

    private static void add(Step s, int timeout) { queue.add(new Entry(s, timeout)); }

    // ------------------------------------------------------------------- tick

    public static void tick(MinecraftClient mc) {
        if (!active) return;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) { reset(mc); return; }
        if (cooldown > 0) { cooldown--; return; }

        int guard = 0;
        while (!queue.isEmpty() && guard++ < 64) {
            Entry e = queue.peek();
            boolean done;
            try {
                done = e.step().run(mc, ctx);
            } catch (Exception ex) {
                FastShulkerClient.LOGGER.error("Etap zamiany nie powiodl sie", ex);
                fail(mc, ex.getMessage() == null ? "blad" : ex.getMessage());
                return;
            }
            if (!done) {
                if (++stepAge > e.timeout()) fail(mc, "przekroczono czas oczekiwania");
                return;
            }
            queue.poll();
            stepAge = 0;
            int d = FastShulkerConfig.get().delayTicks;
            if (d > 0 && !queue.isEmpty()) { cooldown = d; return; }
        }
        if (queue.isEmpty()) finish(mc);
    }

    private static void finish(MinecraftClient mc) {
        if (ctx != null && !ctx.cleaning) msg(mc, "Zamieniono: " + ctx.preset.name);
        reset(mc);
    }

    private static void fail(MinecraftClient mc, String reason) {
        msg(mc, "Przerwano: " + reason);
        queue.clear();
        stepAge = 0;
        cooldown = 0;
        if (ctx != null && !ctx.cleaning && mc.player != null && mc.world != null) {
            if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) mc.player.closeHandledScreen();
            if (ctx.pos != null && mc.world.getBlockState(ctx.pos).getBlock() instanceof ShulkerBoxBlock) {
                // sprobuj chociaz zebrac postawionego shulkera
                ctx.cleaning = true;
                ctx.breakStarted = false;
                ctx.wait = 0;
                add(SwapRunner::breakBlock, 600);
                add(SwapRunner::waitPickup, 40);
                return;
            }
        }
        reset(mc);
    }

    private static void reset(MinecraftClient mc) {
        if (ctx != null && mc.player != null && mc.getNetworkHandler() != null) {
            select(mc, ctx.origSelected);
        }
        queue.clear();
        ctx = null;
        active = false;
        cooldown = 0;
        stepAge = 0;
    }

    // ------------------------------------------------------------------ etapy

    /** Jesli shulker lezy w glownym ekwipunku, przenosi go na wybrany slot hotbara. */
    private static boolean prep(MinecraftClient mc, Ctx c) {
        PlayerInventory inv = mc.player.getInventory();
        int idx = ShulkerUtil.find(inv, c.preset);
        if (idx < 0) throw new IllegalStateException("shulker zniknal z ekwipunku");
        if (idx >= 9) {
            click(mc, idx, inv.selectedSlot, SlotActionType.SWAP);
            c.shulkerHotbar = inv.selectedSlot;
        } else {
            c.shulkerHotbar = idx;
        }
        return true;
    }

    private static boolean place(MinecraftClient mc, Ctx c) {
        if (!c.placeSent) {
            select(mc, c.shulkerHotbar);
            BlockPos below = c.pos.down();
            Vec3d hit = new Vec3d(c.pos.getX() + 0.5, c.pos.getY(), c.pos.getZ() + 0.5);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(hit, Direction.UP, below, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            c.placeSent = true;
            return false;
        }
        return mc.world.getBlockState(c.pos).getBlock() instanceof ShulkerBoxBlock;
    }

    private static boolean open(MinecraftClient mc, Ctx c) {
        if (mc.player.currentScreenHandler instanceof ShulkerBoxScreenHandler) {
            return ++c.settle > 1; // chwila na synchronizacje zawartosci
        }
        if (!c.openSent) {
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(Vec3d.ofCenter(c.pos), Direction.UP, c.pos, false));
            c.openSent = true;
        }
        return false;
    }

    private static boolean swapInside(MinecraftClient mc, Ctx c) {
        if (!(mc.player.currentScreenHandler instanceof ShulkerBoxScreenHandler)) {
            throw new IllegalStateException("okno shulkera sie zamknelo");
        }
        int[] l = c.layout;
        // hotbar (przycisk SWAP = numer slotu hotbara) i offhand (40)
        for (int t = 0; t < 9; t++) if (l[t] >= 0) click(mc, l[t], t, SlotActionType.SWAP);
        if (l[9] >= 0) click(mc, l[9], 40, SlotActionType.SWAP);

        // pancerz: nowe czesci laduja w buforze (glowny ekwipunek), stare wroca do shulkera pozniej
        boolean armor = false;
        for (int k = 10; k <= 13; k++) if (l[k] >= 0) armor = true;
        if (armor) {
            if (!chooseBuffers(mc, c)) throw new IllegalStateException("brak miejsca w ekwipunku na zamiane pancerza");
            for (int k = 0; k < 4; k++) {
                if (l[10 + k] >= 0) swap3(mc, l[10 + k], c.buf[k] + 18); // 18 = przesuniecie: ekwipunek 9.. -> slot shulkera 27..
            }
        }
        return true;
    }

    private static boolean closeScreen(MinecraftClient mc, Ctx c) {
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) mc.player.closeHandledScreen();
        c.openSent = false;
        c.settle = 0;
        return true;
    }

    /** Bez otwartego okna: zaloz nowy pancerz z bufora, stary laduje w buforze. */
    private static boolean equipArmor(MinecraftClient mc, Ctx c) {
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return false;
        for (int k = 0; k < 4; k++) {
            if (c.layout[10 + k] >= 0) swap3(mc, c.buf[k], 5 + k); // sloty pancerza w oknie gracza: 5-8
        }
        return true;
    }

    /** Ponownie w shulkerze: stary pancerz z bufora trafia do shulkera, a przedmiot z bufora wraca na miejsce. */
    private static boolean restoreArmor(MinecraftClient mc, Ctx c) {
        if (!(mc.player.currentScreenHandler instanceof ShulkerBoxScreenHandler)) {
            throw new IllegalStateException("okno shulkera sie zamknelo");
        }
        for (int k = 0; k < 4; k++) {
            if (c.layout[10 + k] >= 0) swap3(mc, c.layout[10 + k], c.buf[k] + 18);
        }
        return true;
    }

    private static boolean breakBlock(MinecraftClient mc, Ctx c) {
        BlockState st = mc.world.getBlockState(c.pos);
        if (!(st.getBlock() instanceof ShulkerBoxBlock)) return true;
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return false;

        if (!c.breakStarted) {
            PlayerInventory inv = mc.player.getInventory();
            int best = inv.selectedSlot;
            float bestSpeed = inv.getStack(best).getMiningSpeedMultiplier(st);
            for (int i = 0; i < 9; i++) {
                float sp = inv.getStack(i).getMiningSpeedMultiplier(st);
                if (sp > bestSpeed) { bestSpeed = sp; best = i; }
            }
            select(mc, best);
            mc.interactionManager.attackBlock(c.pos, Direction.UP);
            c.breakStarted = true;
        } else {
            mc.interactionManager.updateBlockBreakingProgress(c.pos, Direction.UP);
        }
        mc.player.swingHand(Hand.MAIN_HAND);
        return false;
    }

    private static boolean waitPickup(MinecraftClient mc, Ctx c) {
        if (ShulkerUtil.find(mc.player.getInventory(), c.preset) >= 0) return true;
        return ++c.wait >= 30;
    }

    // ---------------------------------------------------------------- pomocnicze

    private static void click(MinecraftClient mc, int slot, int button, SlotActionType type) {
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, button, type, mc.player);
    }

    /** Zamiana dwoch slotow zwyklymi kliknieciami (a, b, a). */
    private static void swap3(MinecraftClient mc, int a, int b) {
        click(mc, a, 0, SlotActionType.PICKUP);
        click(mc, b, 0, SlotActionType.PICKUP);
        click(mc, a, 0, SlotActionType.PICKUP);
    }

    private static void select(MinecraftClient mc, int slot) {
        mc.player.getInventory().selectedSlot = slot;
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
    }

    private static boolean chooseBuffers(MinecraftClient mc, Ctx c) {
        PlayerInventory inv = mc.player.getInventory();
        int k = 0;
        for (int i = 9; i < 36 && k < 4; i++) {
            ItemStack s = inv.getStack(i);
            if (!ShulkerUtil.isShulker(s)) c.buf[k++] = i; // shulker nie wejdzie do shulkera
        }
        return k == 4;
    }

    /** Wolny blok tuz obok gracza (w zasiegu podnoszenia itemow), z miejscem nad nim na wieko. */
    private static BlockPos findPlacePos(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        BlockPos base = p.getBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    BlockPos below = pos.down();
                    if (!mc.world.getBlockState(pos).isAir()) continue;
                    if (!mc.world.getBlockState(pos.up()).isAir()) continue;
                    if (!mc.world.getBlockState(below).isSideSolidFullSquare(mc.world, below, Direction.UP)) continue;
                    if (p.getBoundingBox().intersects(new Box(pos))) continue;
                    if (p.getBoundingBox().intersects(new Box(pos.up()))) continue;
                    double d = p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos));
                    if (d < bestD) { bestD = d; best = pos; }
                }
            }
        }
        return best;
    }

    private static void msg(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("[FastShulker] " + s), true);
    }
}
