package com.fastshulker.config;

import java.util.Arrays;

/**
 * Jeden preset: nazwa, bind, wskazanie shulkera i uklad.
 * layout[cel] = numer slotu w shulkerze (0-26) albo -1 (nie ruszaj).
 * Cele: 0-8 hotbar, 9 offhand, 10 helm, 11 napiersnik, 12 spodnie, 13 buty.
 */
public class Preset {
    public static final int TARGETS = 14;

    public String name = "Preset";
    public int key = -1;
    public String shulkerItem = "";
    public String shulkerName = "";
    public int[] layout = emptyLayout();

    public static int[] emptyLayout() {
        int[] a = new int[TARGETS];
        Arrays.fill(a, -1);
        return a;
    }

    public void sanitize() {
        if (name == null) name = "Preset";
        if (shulkerItem == null) shulkerItem = "";
        if (shulkerName == null) shulkerName = "";
        if (layout == null || layout.length != TARGETS) layout = emptyLayout();
        for (int i = 0; i < layout.length; i++) {
            if (layout[i] < -1 || layout[i] > 26) layout[i] = -1;
        }
    }

    public boolean isEmpty() {
        for (int v : layout) if (v >= 0) return false;
        return true;
    }
}
