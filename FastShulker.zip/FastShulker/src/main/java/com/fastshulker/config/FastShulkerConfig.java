package com.fastshulker.config;

import com.fastshulker.FastShulkerClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class FastShulkerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static FastShulkerConfig instance;

    /** Opoznienie (w tickach) miedzy etapami zamiany. 0 = jak najszybciej. */
    public int delayTicks = 1;
    public List<Preset> presets = new ArrayList<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("fastshulker.json");
    }

    public static FastShulkerConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        FastShulkerConfig cfg = null;
        Path f = file();
        if (Files.exists(f)) {
            try (Reader r = Files.newBufferedReader(f)) {
                cfg = GSON.fromJson(r, FastShulkerConfig.class);
            } catch (Exception e) {
                FastShulkerClient.LOGGER.error("Nie udalo sie wczytac configu", e);
            }
        }
        if (cfg == null) cfg = new FastShulkerConfig();
        if (cfg.presets == null) cfg.presets = new ArrayList<>();
        cfg.presets.removeIf(Objects::isNull);
        for (Preset p : cfg.presets) p.sanitize();
        cfg.delayTicks = Math.max(0, Math.min(20, cfg.delayTicks));
        instance = cfg;
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(get()));
        } catch (IOException e) {
            FastShulkerClient.LOGGER.error("Nie udalo sie zapisac configu", e);
        }
    }
}
