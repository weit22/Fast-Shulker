package com.fastshulker.util;

import com.fastshulker.config.Preset;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.client.util.InputUtil;

public final class ShulkerUtil {
    private ShulkerUtil() {}

    public static boolean isShulker(ItemStack s) {
        return !s.isEmpty() && s.getItem() instanceof BlockItem bi && bi.getBlock() instanceof ShulkerBoxBlock;
    }

    public static String idOf(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).toString();
    }

    public static String customNameOf(ItemStack s) {
        Text t = s.get(DataComponentTypes.CUSTOM_NAME);
        return t == null ? "" : t.getString();
    }

    public static boolean matches(ItemStack s, Preset p) {
        if (!isShulker(s) || p.shulkerItem.isEmpty()) return false;
        if (!idOf(s).equals(p.shulkerItem)) return false;
        return p.shulkerName.isEmpty() || p.shulkerName.equals(customNameOf(s));
    }

    /** Indeks w ekwipunku gracza (0-35) pierwszego pasujacego shulkera albo -1. */
    public static int find(PlayerInventory inv, Preset p) {
        for (int i = 0; i < 36; i++) {
            if (matches(inv.getStack(i), p)) return i;
        }
        return -1;
    }

    /** Zawartosc shulkera (27 slotow, z zachowaniem pozycji). */
    public static DefaultedList<ItemStack> contents(ItemStack shulker) {
        DefaultedList<ItemStack> list = DefaultedList.ofSize(27, ItemStack.EMPTY);
        ContainerComponent c = shulker.get(DataComponentTypes.CONTAINER);
        if (c != null) c.copyTo(list);
        return list;
    }

    public static String keyName(int key) {
        if (key < 0) return "brak";
        return InputUtil.fromKeyCode(key, -1).getLocalizedText().getString();
    }
}
