package com.fastshulker.gui;

import com.fastshulker.config.FastShulkerConfig;
import com.fastshulker.config.Preset;
import com.fastshulker.util.ShulkerUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Edytor presetu. Po lewej cele (hotbar, offhand, pancerz), po prawej zawartosc shulkera.
 * Kliknij slot po lewej, potem przedmiot po prawej (albo odwrotnie), zeby go przypisac.
 */
public class PresetEditScreen extends Screen {
    private static final int S = 18;
    private static final String[] TARGET_NAMES = {
            "Hotbar 1", "Hotbar 2", "Hotbar 3", "Hotbar 4", "Hotbar 5", "Hotbar 6", "Hotbar 7", "Hotbar 8", "Hotbar 9",
            "Offhand", "Helm", "Napiersnik", "Spodnie", "Buty"};
    private static final String[] TARGET_LABELS = {
            "1", "2", "3", "4", "5", "6", "7", "8", "9", "O", "H", "C", "L", "B"};

    private final Screen parent;
    private final Preset preset;

    private TextFieldWidget nameField;
    private ButtonWidget bindButton;
    private ButtonWidget shulkerButton;
    private boolean capturing;
    private int selTarget = -1;
    private int selSource = -1;

    private ItemStack shulker = ItemStack.EMPTY;
    private DefaultedList<ItemStack> contents = DefaultedList.ofSize(27, ItemStack.EMPTY);

    private int leftX, rightX, topY;

    public PresetEditScreen(Screen parent, Preset preset) {
        super(Text.literal("Edycja presetu"));
        this.parent = parent;
        this.preset = preset;
    }

    // ---------------------------------------------------------------- init

    @Override
    protected void init() {
        int cx = width / 2;
        leftX = cx - 170;
        rightX = cx + 8;
        topY = 84;

        nameField = new TextFieldWidget(textRenderer, cx - 170, 16, 165, 20, Text.literal("Nazwa"));
        nameField.setMaxLength(32);
        nameField.setText(preset.name);
        nameField.setChangedListener(t -> preset.name = t);
        addDrawableChild(nameField);

        bindButton = ButtonWidget.builder(bindText(), b -> {
            capturing = true;
            b.setMessage(Text.literal("> nacisnij klawisz (ESC = brak) <"));
        }).dimensions(cx + 5, 16, 165, 20).build();
        addDrawableChild(bindButton);

        shulkerButton = ButtonWidget.builder(shulkerText(), b -> cycleShulker())
                .dimensions(cx - 170, 40, 340, 20).build();
        addDrawableChild(shulkerButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Wyczysc uklad"), b -> {
            Arrays.fill(preset.layout, -1);
            selTarget = -1;
            selSource = -1;
        }).dimensions(cx - 170, height - 28, 165, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Gotowe"), b -> close())
                .dimensions(cx + 5, height - 28, 165, 20).build());

        refreshShulker();
        shulkerButton.setMessage(shulkerText());
    }

    private Text bindText() {
        return Text.literal("Bind: " + ShulkerUtil.keyName(preset.key));
    }

    private Text shulkerText() {
        if (preset.shulkerItem.isEmpty()) return Text.literal("Shulker: kliknij, aby wybrac z ekwipunku");
        String n = shulker.isEmpty() ? preset.shulkerItem + " (brak w ekwipunku)" : shulker.getName().getString();
        return Text.literal("Shulker: " + n + "  (kliknij, aby zmienic)");
    }

    private void refreshShulker() {
        shulker = ItemStack.EMPTY;
        contents = DefaultedList.ofSize(27, ItemStack.EMPTY);
        if (client == null || client.player == null) return;
        PlayerInventory inv = client.player.getInventory();
        int idx = ShulkerUtil.find(inv, preset);
        if (idx >= 0) {
            shulker = inv.getStack(idx);
            contents = ShulkerUtil.contents(shulker);
        }
    }

    private void cycleShulker() {
        if (client == null || client.player == null) return;
        PlayerInventory inv = client.player.getInventory();
        List<ItemStack> list = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (ShulkerUtil.isShulker(s) && seen.add(ShulkerUtil.idOf(s) + "|" + ShulkerUtil.customNameOf(s))) {
                list.add(s);
            }
        }
        if (list.isEmpty()) {
            client.player.sendMessage(Text.literal("[FastShulker] Brak shulkerow w ekwipunku."), true);
            return;
        }
        int cur = -1;
        for (int j = 0; j < list.size(); j++) if (ShulkerUtil.matches(list.get(j), preset)) cur = j;
        ItemStack next = list.get((cur + 1) % list.size());
        preset.shulkerItem = ShulkerUtil.idOf(next);
        preset.shulkerName = ShulkerUtil.customNameOf(next);
        Arrays.fill(preset.layout, -1);
        selTarget = -1;
        selSource = -1;
        refreshShulker();
        shulkerButton.setMessage(shulkerText());
    }

    // ------------------------------------------------------------ geometria

    private int tx(int t) {
        if (t < 9) return leftX + t * S;
        if (t == 9) return leftX;
        return leftX + (t - 9) * S + 10;
    }

    private int ty(int t) { return t < 9 ? topY : topY + S + 8; }
    private int sx(int s) { return rightX + (s % 9) * S; }
    private int sy(int s) { return topY + (s / 9) * S; }
    private boolean in(int mx, int my, int x, int y) { return mx >= x && mx < x + S && my >= y && my < y + S; }

    private int hitTarget(int mx, int my) {
        for (int t = 0; t < Preset.TARGETS; t++) if (in(mx, my, tx(t), ty(t))) return t;
        return -1;
    }

    private int hitSource(int mx, int my) {
        for (int s = 0; s < 27; s++) if (in(mx, my, sx(s), sy(s))) return s;
        return -1;
    }

    // -------------------------------------------------------------- rysowanie

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);

        ctx.drawTextWithShadow(textRenderer, Text.literal("Cel (Twoje eq po zamianie)"), leftX, topY - 12, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Zawartosc shulkera"), rightX, topY - 12, 0xFFFFFFFF);

        boolean[] used = new boolean[27];
        for (int v : preset.layout) if (v >= 0) used[v] = true;

        for (int t = 0; t < Preset.TARGETS; t++) {
            int src = preset.layout[t];
            ItemStack st = src >= 0 ? contents.get(src) : ItemStack.EMPTY;
            int border = selTarget == t ? 0xFFFFFF55 : 0;
            drawSlot(ctx, tx(t), ty(t), st, border);
            if (st.isEmpty()) {
                String l = TARGET_LABELS[t];
                ctx.drawTextWithShadow(textRenderer, Text.literal(l),
                        tx(t) + (S - textRenderer.getWidth(l)) / 2, ty(t) + 5, 0xFF777777);
            }
        }

        for (int s = 0; s < 27; s++) {
            int border = selSource == s ? 0xFFFFFF55 : (used[s] ? 0xFF55FF55 : 0);
            drawSlot(ctx, sx(s), sy(s), contents.get(s), border);
        }

        int hy = topY + 3 * S + 8;
        ctx.drawTextWithShadow(textRenderer,
                Text.literal("Kliknij slot po lewej, potem przedmiot z shulkera (albo odwrotnie)."), leftX, hy, 0xFFAAAAAA);
        ctx.drawTextWithShadow(textRenderer,
                Text.literal("PPM na slocie po lewej = wyczysc. Zielona ramka = przedmiot juz przypisany."), leftX, hy + 11, 0xFFAAAAAA);
        ctx.drawTextWithShadow(textRenderer,
                Text.literal("Nie sneakuj podczas zamiany. Nazwij shulkery kowadlem, zeby je rozroznic."), leftX, hy + 22, 0xFFAAAAAA);

        int ht = hitTarget(mx, my);
        int hs = hitSource(mx, my);
        if (ht >= 0) {
            int src = preset.layout[ht];
            if (src >= 0 && !contents.get(src).isEmpty()) {
                ctx.drawItemTooltip(textRenderer, contents.get(src), mx, my);
            } else {
                ctx.drawTooltip(textRenderer, Text.literal(TARGET_NAMES[ht]), mx, my);
            }
        } else if (hs >= 0 && !contents.get(hs).isEmpty()) {
            ctx.drawItemTooltip(textRenderer, contents.get(hs), mx, my);
        }
    }

    private void drawSlot(DrawContext ctx, int x, int y, ItemStack stack, int border) {
        ctx.fill(x, y, x + S, y + S, 0xFF555555);
        ctx.fill(x + 1, y + 1, x + S - 1, y + S - 1, 0xFF2B2B2B);
        if (border != 0) ctx.drawBorder(x, y, S, S, border);
        if (!stack.isEmpty()) {
            ctx.drawItem(stack, x + 1, y + 1);
            ctx.drawStackOverlay(textRenderer, stack, x + 1, y + 1);
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        int mx = (int) mouseX, my = (int) mouseY;

        int t = hitTarget(mx, my);
        if (t >= 0) {
            if (button == 1) {
                preset.layout[t] = -1;
            } else if (selSource >= 0) {
                assign(t, selSource);
                selSource = -1;
                selTarget = -1;
            } else {
                selTarget = selTarget == t ? -1 : t;
            }
            return true;
        }

        int s = hitSource(mx, my);
        if (s >= 0 && !contents.get(s).isEmpty()) {
            if (selTarget >= 0) {
                assign(selTarget, s);
                selSource = -1;
                selTarget = -1;
            } else {
                selSource = selSource == s ? -1 : s;
            }
            return true;
        }
        return false;
    }

    private void assign(int target, int source) {
        if (!canAssign(target, source)) {
            if (client != null && client.player != null) {
                client.player.sendMessage(Text.literal("[FastShulker] Ten przedmiot nie pasuje do slotu: "
                        + TARGET_NAMES[target]), true);
            }
            return;
        }
        for (int i = 0; i < preset.layout.length; i++) if (preset.layout[i] == source) preset.layout[i] = -1;
        preset.layout[target] = source;
    }

    private boolean canAssign(int target, int source) {
        ItemStack st = contents.get(source);
        if (st.isEmpty()) return false;
        if (target < 10) return true;
        EquippableComponent eq = st.get(DataComponentTypes.EQUIPPABLE);
        if (eq == null) return false;
        EquipmentSlot need = switch (target) {
            case 10 -> EquipmentSlot.HEAD;
            case 11 -> EquipmentSlot.CHEST;
            case 12 -> EquipmentSlot.LEGS;
            default -> EquipmentSlot.FEET;
        };
        return eq.slot() == need;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (capturing) {
            preset.key = keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode;
            capturing = false;
            bindButton.setMessage(bindText());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        FastShulkerConfig.save();
        client.setScreen(parent);
    }
}
