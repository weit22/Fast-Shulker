package com.fastshulker.gui;

import com.fastshulker.config.FastShulkerConfig;
import com.fastshulker.config.Preset;
import com.fastshulker.util.ShulkerUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

public class PresetListScreen extends Screen {
    private static final int PER_PAGE = 5;

    private final Screen parent;
    private int page;

    public PresetListScreen(Screen parent, int page) {
        super(Text.literal("FastShulker - presety"));
        this.parent = parent;
        this.page = page;
    }

    @Override
    protected void init() {
        FastShulkerConfig cfg = FastShulkerConfig.get();
        List<Preset> presets = cfg.presets;
        int cx = width / 2;
        int pages = Math.max(1, (presets.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        int start = page * PER_PAGE;

        for (int i = 0; i < PER_PAGE && start + i < presets.size(); i++) {
            final Preset p = presets.get(start + i);
            int y = 30 + i * 24;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(p.name + "   [" + ShulkerUtil.keyName(p.key) + "]"),
                    b -> client.setScreen(new PresetEditScreen(this, p)))
                    .dimensions(cx - 150, y, 240, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Usun"), b -> {
                presets.remove(p);
                FastShulkerConfig.save();
                client.setScreen(new PresetListScreen(parent, page));
            }).dimensions(cx + 95, y, 55, 20).build());
        }

        int navY = 30 + PER_PAGE * 24 + 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            page--;
            client.setScreen(new PresetListScreen(parent, page));
        }).dimensions(cx - 150, navY, 30, 20).build()).active = page > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            page++;
            client.setScreen(new PresetListScreen(parent, page));
        }).dimensions(cx + 120, navY, 30, 20).build()).active = page < pages - 1;

        int delayY = navY + 26;
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
            cfg.delayTicks = Math.max(0, cfg.delayTicks - 1);
            FastShulkerConfig.save();
        }).dimensions(cx - 150, delayY, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
            cfg.delayTicks = Math.min(20, cfg.delayTicks + 1);
            FastShulkerConfig.save();
        }).dimensions(cx + 120, delayY, 30, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Nowy preset"), b -> {
            Preset p = new Preset();
            p.name = "Preset " + (presets.size() + 1);
            presets.add(p);
            FastShulkerConfig.save();
            client.setScreen(new PresetEditScreen(this, p));
        }).dimensions(cx - 150, height - 28, 145, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Gotowe"), b -> close())
                .dimensions(cx + 5, height - 28, 145, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        FastShulkerConfig cfg = FastShulkerConfig.get();
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, title, cx, 12, 0xFFFFFFFF);
        if (cfg.presets.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Brak presetow - kliknij \"Nowy preset\""), cx, 60, 0xFFAAAAAA);
        }
        int delayY = 30 + PER_PAGE * 24 + 2 + 26;
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Opoznienie miedzy etapami: " + cfg.delayTicks + " tick"), cx, delayY + 6, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        FastShulkerConfig.save();
        client.setScreen(parent);
    }
}
