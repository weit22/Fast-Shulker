package com.fastshulker;

import com.fastshulker.config.FastShulkerConfig;
import com.fastshulker.config.Preset;
import com.fastshulker.gui.PresetListScreen;
import com.fastshulker.swap.SwapRunner;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class FastShulkerClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("FastShulker");

    private static KeyBinding openGui;
    private static final Map<Integer, Boolean> wasDown = new HashMap<>();

    @Override
    public void onInitializeClient() {
        FastShulkerConfig.load();
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fastshulker.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.fastshulker"));
        ClientTickEvents.END_CLIENT_TICK.register(FastShulkerClient::onTick);
    }

    private static void onTick(MinecraftClient mc) {
        SwapRunner.tick(mc);
        if (mc.player == null || mc.world == null) return;

        while (openGui.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new PresetListScreen(null, 0));
        }

        long window = mc.getWindow().getHandle();
        boolean free = mc.currentScreen == null && !SwapRunner.isRunning();
        for (Preset p : FastShulkerConfig.get().presets) {
            if (p.key < 0) continue;
            boolean down = InputUtil.isKeyPressed(window, p.key);
            boolean was = wasDown.getOrDefault(p.key, false);
            if (free && down && !was) SwapRunner.start(mc, p);
            wasDown.put(p.key, down);
        }
    }
}
