# FastShulker

Mod **tylko po stronie klienta** (Fabric, Minecraft 1.21.4). Jeden klawisz zamienia Twoj pancerz, offhand i hotbar z zestawem zapisanym w shulkerze.

## Jak uzywac
1. Wejdz do gry z modem, nacisnij **Right Shift** (zmienisz w Sterowanie -> FastShulker).
2. **Nowy preset** -> wpisz nazwe, kliknij **Bind** i nacisnij klawisz.
3. Kliknij przycisk **Shulker**, zeby wybrac shulkera z ekwipunku (kolejne klikniecia przelaczaja miedzy shulkerami).
4. Po prawej widzisz zawartosc shulkera, po lewej cele (hotbar, offhand, pancerz).
   Kliknij slot po lewej, potem przedmiot po prawej (albo odwrotnie). PPM czysci slot.
5. **Gotowe**. Nacisniecie bindu w grze robi zamiane; ponowne nacisniecie wraca do poprzedniego eq.

## Co dzieje sie pod spodem
Zawartosc shulkera mozna ruszac tylko gdy stoi i jest otwarty, wiec mod robi to samo co Ty, tylko szybko:
postawienie shulkera obok -> otwarcie -> zamiana slotow -> zamkniecie -> zniszczenie -> podniesienie.
Pancerz wymaga dodatkowego otwarcia shulkera (zakladanie odbywa sie poza oknem shulkera).

## Ustawienia
Plik `config/fastshulker.json`. Opoznienie miedzy etapami ustawisz w menu (0 = najszybciej;
na serwerach z anticheatem zwieksz).

## Ograniczenia
- Potrzebne wolne miejsce tuz obok gracza (blok z lita podloga i wolnym blokiem nad nim).
- Nie sneakuj w trakcie zamiany.
- Shulker nie wejdzie do shulkera, wiec shulkery w ekwipunku nie moga byc czescia zestawu.
- Do zamiany pancerza potrzeba 4 wolnych/nieshulkerowych slotow w glownym ekwipunku (bufor).
- Dwa shulkery tego samego koloru rozrozniaj nazwa (kowadlo).
- Mod automatyzuje akcje - sprawdz regulamin serwera.

## Budowanie
Wymagane JDK 21. `./gradlew build` -> jar w `build/libs/`. Test: `./gradlew runClient`.
Brakujace pliki `gradlew`, `gradlew.bat` i `gradle/wrapper/gradle-wrapper.jar` skopiuj z szablonu
ze strony https://fabricmc.net/develop/template/ (1.21.4).
